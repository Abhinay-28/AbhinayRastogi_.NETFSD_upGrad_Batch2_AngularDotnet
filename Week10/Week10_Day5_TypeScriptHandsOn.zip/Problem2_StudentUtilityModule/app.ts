import { Student } from "./student.model";
import { getGrade, getTopper } from "./student.service";
import { calculateAverage, formatName } from "./utils";
import { PASS_MARKS } from "./constants";

const students: Student[] = [
    { id: 1, name: "rahul", marks: 85 },
    { id: 2, name: "aisha", marks: 92 },
    { id: 3, name: "karan", marks: 38 },
    { id: 4, name: "neha", marks: 76 }
];

console.log("Pass Marks:", PASS_MARKS);

console.log("\nStudent Details:");
for (const student of students) {
    console.log(
        `Id: ${student.id}, Name: ${formatName(student.name)}, Marks: ${student.marks}, Grade: ${getGrade(student.marks)}`
    );
}

const averageMarks = calculateAverage(students);
const topper = getTopper(students);

console.log("\nAverage Marks:", averageMarks);
console.log("Topper:", formatName(topper.name), "-", topper.marks);
