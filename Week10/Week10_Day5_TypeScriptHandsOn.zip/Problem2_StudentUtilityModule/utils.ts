import { Student } from "./student.model";

export function formatName(name: string): string {
    if (name.length === 0) {
        return name;
    }

    return name.charAt(0).toUpperCase() + name.slice(1).toLowerCase();
}

export function calculateAverage(students: Student[]): number {
    if (students.length === 0) {
        return 0;
    }

    const totalMarks = students.reduce((sum, student) => sum + student.marks, 0);
    return totalMarks / students.length;
}
