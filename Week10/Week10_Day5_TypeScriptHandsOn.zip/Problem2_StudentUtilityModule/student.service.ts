import { Student } from "./student.model";
import { PASS_MARKS } from "./constants";

export function getGrade(marks: number): string {
    if (marks >= 90) {
        return "A";
    }

    if (marks >= 75) {
        return "B";
    }

    if (marks >= 60) {
        return "C";
    }

    if (marks >= PASS_MARKS) {
        return "D";
    }

    return "Fail";
}

export function getTopper(students: Student[]): Student {
    if (students.length === 0) {
        throw new Error("Student list cannot be empty.");
    }

    return students.reduce((topper, current) =>
        current.marks > topper.marks ? current : topper
    );
}
