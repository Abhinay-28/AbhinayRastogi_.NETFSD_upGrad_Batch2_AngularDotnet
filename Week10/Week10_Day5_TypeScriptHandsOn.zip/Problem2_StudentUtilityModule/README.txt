Problem 2 - Student Utility Module using TypeScript Modules & Imports

Run:
ts-node app.ts

Or compile:
tsc
node dist/app.js

Files:
- student.model.ts
- student.service.ts
- utils.ts
- constants.ts
- app.ts

Concepts covered:
- export/import
- ES6 modules
- separation of concerns
- strict typing
