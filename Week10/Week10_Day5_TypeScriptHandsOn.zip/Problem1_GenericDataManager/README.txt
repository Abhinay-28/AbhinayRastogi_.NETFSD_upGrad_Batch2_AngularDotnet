Problem 1 - Reusable Data Manager using Generics

Run:
ts-node app.ts

Or compile:
tsc
node dist/app.js

Concepts covered:
- Generic function
- Generic interface
- Generic class
- Type-safe reusable data manager
