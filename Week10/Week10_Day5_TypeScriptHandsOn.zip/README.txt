Week-10 Day-5 TypeScript Hands-On

This zip contains:

1. Problem1_GenericDataManager
   - Generic function
   - Generic interface
   - Generic class
   - User and Product examples

2. Problem2_StudentUtilityModule
   - TypeScript modules
   - import/export
   - student model
   - service functions
   - utility functions
   - constants

Recommended setup:
npm install -g typescript ts-node

Run each problem separately from its folder:
ts-node app.ts

Or compile:
tsc
node dist/app.js
