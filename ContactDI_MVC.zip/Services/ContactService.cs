using System.Collections.Generic;
using System.Linq;

public class ContactService : IContactService
{
    private static List<ContactInfo> contacts = new List<ContactInfo>();

    public void AddContact(ContactInfo contact)
    {
        contacts.Add(contact);
    }

    public List<ContactInfo> GetAllContacts()
    {
        return contacts;
    }

    public ContactInfo GetContactById(int id)
    {
        return contacts.FirstOrDefault(x => x.ContactId == id);
    }
}