using Microsoft.AspNetCore.Mvc;

public class ContactController : Controller
{
    private readonly IContactService _service;

    public ContactController(IContactService service)
    {
        _service = service;
    }

    public IActionResult ShowContacts()
    {
        return View(_service.GetAllContacts());
    }

    public IActionResult AddContact()
    {
        return View();
    }

    [HttpPost]
    public IActionResult AddContact(ContactInfo c)
    {
        _service.AddContact(c);
        return RedirectToAction("ShowContacts");
    }
}