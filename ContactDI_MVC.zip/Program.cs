var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();
builder.Services.AddSingleton<IContactService, ContactService>();
var app = builder.Build();
app.UseRouting();
app.MapControllerRoute(name: "default",
pattern: "{controller=Contact}/{action=ShowContacts}/{id?}");
app.Run();