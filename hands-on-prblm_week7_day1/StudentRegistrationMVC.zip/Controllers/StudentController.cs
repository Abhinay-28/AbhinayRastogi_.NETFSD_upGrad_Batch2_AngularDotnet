using Microsoft.AspNetCore.Mvc;

public class StudentController : Controller
{
    [HttpGet("student/form")]
    public IActionResult Form()
    {
        return View();
    }

    [HttpPost("student/submit")]
    public IActionResult Submit(string name, int age, string course)
    {
        ViewBag.Name = name;
        ViewBag.Age = age;
        ViewBag.Course = course;
        return View("Display");
    }
}